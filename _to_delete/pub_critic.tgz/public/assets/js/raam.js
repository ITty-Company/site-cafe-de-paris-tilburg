/* Café de Paris — raam.js: Three.js «Het Raam». Een oude etalageruit (MeshPhysical transmission, licht golvend glas) met
   bolle bladgoud-letters «Café de Paris» (gestapelde CanvasTexture-lagen = reliëf) in een groene houten pui. Scroll = camera loopt
   van de straat DOOR het glas naar binnen en kijkt om: het opschrift wordt spiegelschrift; de zon schuift van ochtend naar avond.
   Drag ±0.6 rad. Op reserveren schrijft de naam van de gast zich in goud op het glas. Pauzeert buiten beeld; DPR ≤ 2. */
import * as T from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
const g = window.gsap, ST = window.ScrollTrigger;
const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;
const MOB = matchMedia('(max-width:760px)').matches;
const C = { creme: 0xF3ECDF, groen: 0x1E4A38, goud: 0xC29A45, avond: 0x121C17, inkt: 0x1B1F1C, kir: 0x7A2E3A };

// per pagina: bereik van de scroll-voortgang (camera) en het licht
const VIEW = { index: [0, 1], kaart: [0.08, 0.5], over: [0.45, 1], reserveren: [0.02, 0.3], contact: [0.55, 1] };

async function letters(name = '') {
  try { await document.fonts.load('140px "Instrument Serif"'); await document.fonts.load('italic 140px "Instrument Serif"'); } catch (e) { /* fallback serif */ }
  const cv = document.createElement('canvas'); cv.width = 2048; cv.height = 1024; const x = cv.getContext('2d');
  x.clearRect(0, 0, 2048, 1024); x.fillStyle = '#fff'; x.textAlign = 'center'; x.textBaseline = 'alphabetic';
  // boog-tekst
  const txt = 'Café de Paris', R = 1500, cx = 1024, cy = 1880; x.font = '230px "Instrument Serif", Georgia, serif';
  const widths = [...txt].map(c => x.measureText(c).width), tot = widths.reduce((a, b) => a + b, 0);
  let ang = -tot / R / 2;
  [...txt].forEach((c, i) => { const w = widths[i], a = ang + w / R / 2; x.save(); x.translate(cx + R * Math.sin(a), cy - R * Math.cos(a)); x.rotate(a);
    x.font = (c === 'd' || c === 'e') && i > 4 && i < 8 ? 'italic 230px "Instrument Serif", Georgia, serif' : '230px "Instrument Serif", Georgia, serif'; x.fillText(c, 0, 0); x.restore(); ang += w / R; });
  // fijne lijn + naam
  x.fillRect(724, 640, 600, 5);
  x.font = '64px "Instrument Serif", Georgia, serif'; x.fillText('EMMASTRAAT · TILBURG', 1024, 740);
  if (name) { x.font = 'italic 150px "Instrument Serif", Georgia, serif'; x.fillText(name.slice(0, 28), 1024, 930); }
  return cv;
}

function tiles() { const cv = document.createElement('canvas'); cv.width = cv.height = 256; const x = cv.getContext('2d');
  for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) { x.fillStyle = (i + j) % 2 ? '#1B1F1C' : '#EDE4D2'; x.fillRect(i * 32, j * 32, 32, 32); }
  const t = new T.CanvasTexture(cv); t.wrapS = t.wrapT = T.RepeatWrapping; t.repeat.set(6, 6); t.colorSpace = T.SRGBColorSpace; return t; }

function marble() { const cv = document.createElement('canvas'); cv.width = cv.height = 512; const x = cv.getContext('2d');
  x.fillStyle = '#F1ECE4'; x.fillRect(0, 0, 512, 512); x.strokeStyle = 'rgba(120,120,120,.25)';
  for (let k = 0; k < 14; k++) { x.lineWidth = Math.random() * 2 + 0.5; x.beginPath(); let px = Math.random() * 512, py = 0; x.moveTo(px, py);
    for (let s = 0; s < 20; s++) { px += (Math.random() - 0.5) * 60; py += 28; x.lineTo(px, py); } x.stroke(); }
  const t = new T.CanvasTexture(cv); t.colorSpace = T.SRGBColorSpace; return t; }

async function scene(box) {
  const cv = box.querySelector('canvas'), view = box.dataset.view || 'index';
  let R;
  try { R = new T.WebGLRenderer({ canvas: cv, antialias: true, alpha: false, powerPreference: 'high-performance' }); }
  catch (e) { box.classList.add('nogl'); return; }
  R.setPixelRatio(Math.min(devicePixelRatio || 1, MOB ? 1.5 : 2)); R.toneMapping = T.ACESFilmicToneMapping; R.toneMappingExposure = 1.05; R.outputColorSpace = T.SRGBColorSpace;
  const S = new T.Scene(); const bgDay = new T.Color(0xCFDCE0), bgEve = new T.Color(0x0E1A2A); S.background = bgDay.clone(); S.fog = new T.Fog(S.background, 18, 40);
  S.environment = new T.PMREMGenerator(R).fromScene(new RoomEnvironment(), 0.04).texture; S.environmentIntensity = 0.9;
  const cam = new T.PerspectiveCamera(MOB ? 52 : 40, 1, 0.05, 80);

  // --- pui: groene houten lijst + plint
  const wood = new T.MeshStandardMaterial({ color: C.groen, roughness: 0.55, metalness: 0.05 });
  const W = 6.4, H = 3.8, b = 0.28;
  const bar = (w, h, d, x, y, z) => { const m = new T.Mesh(new RoundedBoxGeometry(w, h, d, 3, 0.05), wood); m.position.set(x, y, z); S.add(m); return m; };
  bar(W + 2 * b, b, 0.34, 0, H / 2 + b / 2, 0); bar(W + 2 * b, 1.1, 0.34, 0, -H / 2 - 0.55, 0); bar(b, H + 1.4, 0.34, -W / 2 - b / 2, -0.4, 0); bar(b, H + 1.4, 0.34, W / 2 + b / 2, -0.4, 0);
  // muur rond de pui (buiten)
  const wall = new T.MeshStandardMaterial({ color: 0x2a2620, roughness: 0.9 });
  [[-(W / 2 + b) - 7.5, 0], [(W / 2 + b) + 7.5, 0]].forEach(([x]) => { const p = new T.Mesh(new T.BoxGeometry(15, 14, 0.3), wall); p.position.set(x, 0, -0.04); S.add(p); });
  const top = new T.Mesh(new T.BoxGeometry(W + 2 * b, 6, 0.3), wall); top.position.set(0, H / 2 + b + 3, -0.04); S.add(top);
  // luifel-strook boven de pui
  const awnC = document.createElement('canvas'); awnC.width = 512; awnC.height = 64; const ax = awnC.getContext('2d');
  for (let i = 0; i < 16; i++) { ax.fillStyle = i % 2 ? '#F3ECDF' : '#1E4A38'; ax.fillRect(i * 32, 0, 32, 64); }
  const awnT = new T.CanvasTexture(awnC); awnT.colorSpace = T.SRGBColorSpace;
  const awn = new T.Mesh(new T.PlaneGeometry(W + 1.2, 1.4, 1, 1), new T.MeshStandardMaterial({ map: awnT, roughness: 0.8, side: T.DoubleSide }));
  awn.position.set(0, H / 2 + b + 0.5, 0.75); awn.rotation.x = -0.9; S.add(awn);

  // --- het glas: licht golvend oud glas
  const gg = new T.PlaneGeometry(W, H, 48, 30); const pa = gg.attributes.position;
  for (let i = 0; i < pa.count; i++) { const x = pa.getX(i), y = pa.getY(i); pa.setZ(i, 0.012 * Math.sin(x * 3.1 + y * 0.7) + 0.008 * Math.sin(y * 5.3)); }
  gg.computeVertexNormals();
  const glassM = new T.MeshPhysicalMaterial({ color: 0xdfeee6, metalness: 0, roughness: 0.03, transparent: true, opacity: 0.16, side: T.DoubleSide, envMapIntensity: 1.4, clearcoat: 1, clearcoatRoughness: 0.05, depthWrite: false });
  const glass = new T.Mesh(gg, glassM); S.add(glass);

  // --- bladgoud-letters: 7 gestapelde lagen (reliëf); voorste laag glanst
  let lc = await letters(''), ltex = new T.CanvasTexture(lc); ltex.anisotropy = 8;
  const layers = []; const LN = 7;
  for (let k = 0; k < LN; k++) { const front = k === LN - 1 || k === 0;
    const m = new T.MeshStandardMaterial({ color: front ? C.goud : 0x7a5d22, metalness: 1, roughness: front ? 0.22 : 0.45, alphaMap: ltex, transparent: true, alphaTest: 0.45, side: T.DoubleSide, envMapIntensity: front ? 1.6 : 0.8 });
    const p = new T.Mesh(new T.PlaneGeometry(W * 0.92, W * 0.46), m); p.position.set(0, 0.2, 0.03 + k * 0.0045); S.add(p); layers.push(p); }
  addEventListener('raamnaam', async e => { if (view !== 'reserveren') return; lc = await letters(e.detail.name || ''); ltex.image = lc; ltex.needsUpdate = true; });

  // --- binnen: tegelvloer, marmeren tafeltje met kopje, bank, lampen, achterwand
  const floor = new T.Mesh(new T.PlaneGeometry(16, 16), new T.MeshStandardMaterial({ map: tiles(), roughness: 0.4 })); floor.rotation.x = -Math.PI / 2; floor.position.set(0, -2.95, -7); S.add(floor);
  const street = new T.Mesh(new T.PlaneGeometry(30, 12), new T.MeshStandardMaterial({ color: 0x6b6156, roughness: 0.95 })); street.rotation.x = -Math.PI / 2; street.position.set(0, -2.95, 6); S.add(street);
  const back = new T.Mesh(new T.PlaneGeometry(16, 8), new T.MeshStandardMaterial({ color: 0x173A2C, roughness: 0.7 })); back.position.set(0, 0.6, -12); S.add(back);
  // achterwand: messing planken met flessen en een gebogen spiegel
  const shelfM = new T.MeshStandardMaterial({ color: C.goud, metalness: 1, roughness: 0.28 });
  [-0.6, 0.5, 1.6].forEach(y => { const sh = new T.Mesh(new T.BoxGeometry(10, 0.06, 0.5), shelfM); sh.position.set(0, y, -11.7); S.add(sh); });
  const bottleG = new T.CylinderGeometry(0.09, 0.1, 0.62, 12), bottles = new T.InstancedMesh(bottleG, new T.MeshPhysicalMaterial({ color: 0x8a4a18, roughness: 0.12, metalness: 0.2, clearcoat: 1 }), 66);
  const mtx = new T.Matrix4(); let bi = 0;
  [-0.6, 0.5, 1.6].forEach(y => { for (let k = 0; k < 22; k++) { const x = -4.7 + k * 0.45; if (Math.abs(x) < 1.3) continue; mtx.makeTranslation(x, y + 0.34, -11.65); bottles.setMatrixAt(bi++, mtx); } });
  bottles.count = bi; bottles.instanceMatrix.needsUpdate = true; S.add(bottles);
  const mir = new T.Mesh(new T.PlaneGeometry(2.2, 3.4), new T.MeshStandardMaterial({ color: 0xd8cbb0, metalness: 1, roughness: 0.12 })); mir.position.set(0, 0.6, -11.9); S.add(mir);
  const mirTop = new T.Mesh(new T.CircleGeometry(1.1, 48, 0, Math.PI), mir.material); mirTop.position.set(0, 2.3, -11.9); S.add(mirTop);
  const arcF = new T.Mesh(new T.TorusGeometry(1.15, 0.05, 8, 48, Math.PI), shelfM); arcF.position.set(0, 2.3, -11.85); S.add(arcF);
  // straat aan de overkant (buiten): gevels met ramen die 's avonds aangaan
  const stC = document.createElement('canvas'); stC.width = 1024; stC.height = 256; const sx = stC.getContext('2d'), stE = document.createElement('canvas'); stE.width = 1024; stE.height = 256; const se = stE.getContext('2d');
  sx.fillStyle = '#5a3f31'; sx.fillRect(0, 0, 1024, 256); se.fillStyle = '#000'; se.fillRect(0, 0, 1024, 256);
  for (let i = 0; i < 26; i++) for (let j = 0; j < 3; j++) { const x = 12 + i * 39, y = 40 + j * 70; sx.fillStyle = '#2b2622'; sx.fillRect(x, y, 22, 40); if ((i * 7 + j * 3) % 5 < 3) { se.fillStyle = '#ffcf85'; se.fillRect(x + 2, y + 2, 18, 36); } }
  const stT = new T.CanvasTexture(stC), stET = new T.CanvasTexture(stE); stT.colorSpace = stET.colorSpace = T.SRGBColorSpace;
  const facM = new T.MeshStandardMaterial({ map: stT, emissiveMap: stET, emissive: 0xffffff, emissiveIntensity: 0, roughness: 0.9 });
  const fac = new T.Mesh(new T.PlaneGeometry(36, 9), facM); fac.position.set(0, 1.5, 16); fac.rotation.y = Math.PI; S.add(fac);
  const side1 = new T.Mesh(new T.PlaneGeometry(14, 8), new T.MeshStandardMaterial({ color: 0x1E4A38, roughness: 0.6 })); side1.position.set(-7.5, 0.6, -6); side1.rotation.y = Math.PI / 2; S.add(side1);
  const side2 = side1.clone(); side2.position.x = 7.5; side2.rotation.y = -Math.PI / 2; S.add(side2);
  const ceil = new T.Mesh(new T.PlaneGeometry(16, 14), new T.MeshStandardMaterial({ color: 0x2a3a30, roughness: 0.9 })); ceil.rotation.x = Math.PI / 2; ceil.position.set(0, 4.4, -6); S.add(ceil);
  const brass = new T.MeshStandardMaterial({ color: C.goud, metalness: 1, roughness: 0.3 });
  const table = new T.Group();
  const topM = new T.Mesh(new T.CylinderGeometry(0.85, 0.85, 0.06, 64), new T.MeshStandardMaterial({ map: marble(), roughness: 0.25 })); topM.position.y = 0.0; table.add(topM);
  const rim = new T.Mesh(new T.TorusGeometry(0.85, 0.02, 8, 64), brass); rim.rotation.x = Math.PI / 2; table.add(rim);
  const leg = new T.Mesh(new T.CylinderGeometry(0.05, 0.08, 1.9, 16), new T.MeshStandardMaterial({ color: 0x141414, metalness: 0.6, roughness: 0.4 })); leg.position.y = -0.97; table.add(leg);
  const foot = new T.Mesh(new T.CylinderGeometry(0.4, 0.45, 0.06, 32), leg.material); foot.position.y = -1.92; table.add(foot);
  const porc = new T.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.15, clearcoat: 1 });
  const saucer = new T.Mesh(new T.CylinderGeometry(0.2, 0.15, 0.025, 48), porc); saucer.position.set(0.15, 0.045, 0.1); table.add(saucer);
  const cup = new T.Mesh(new T.CylinderGeometry(0.1, 0.075, 0.13, 40, 1, true), porc); cup.position.set(0.15, 0.12, 0.1); table.add(cup);
  const coffee = new T.Mesh(new T.CircleGeometry(0.095, 32), new T.MeshStandardMaterial({ color: 0x3b2414, roughness: 0.3 })); coffee.rotation.x = -Math.PI / 2; coffee.position.set(0.15, 0.17, 0.1); table.add(coffee);
  const handle = new T.Mesh(new T.TorusGeometry(0.045, 0.012, 8, 20, Math.PI), porc); handle.position.set(0.26, 0.12, 0.1); handle.rotation.z = -Math.PI / 2; table.add(handle);
  table.position.set(0.9, -1.0, -2.2); S.add(table);
  const bank = new T.Mesh(new RoundedBoxGeometry(5, 1.1, 0.9, 4, 0.2), new T.MeshStandardMaterial({ color: 0x5e1f2a, roughness: 0.5 })); bank.position.set(2.6, -2.35, -4.2); S.add(bank);
  const bankB = new T.Mesh(new RoundedBoxGeometry(5, 1.4, 0.4, 4, 0.18), bank.material); bankB.position.set(2.6, -1.5, -4.6); S.add(bankB);
  // bar met koperen rand
  const barM = new T.Mesh(new RoundedBoxGeometry(1.2, 2.2, 7, 3, 0.08), wood); barM.position.set(-5.2, -1.85, -6.5); S.add(barM);
  const barTop = new T.Mesh(new RoundedBoxGeometry(1.4, 0.1, 7.2, 3, 0.04), brass); barTop.position.set(-5.2, -0.72, -6.5); S.add(barTop);
  // lampen-bollen
  const lamps = []; const bulbM = new T.MeshStandardMaterial({ color: 0xfff0cc, emissive: 0xffd38a, emissiveIntensity: 0.2, roughness: 0.3 });
  [[-4.2, 1.9, -9.5], [-1, 2.2, -10.5], [2.4, 2.2, -10.5], [5.4, 1.9, -9.5], [-5.2, 0.2, -4.2], [-5.2, 0.2, -8.6]].forEach(([x, y, z]) => {
    const s = new T.Mesh(new T.SphereGeometry(0.26, 32, 16), bulbM); s.position.set(x, y, z); S.add(s);
    const l = new T.PointLight(0xffc46e, 0, 9, 1.6); l.position.set(x, y - 0.1, z + 0.3); S.add(l); lamps.push(l); });

  // --- licht: zon (spot) schuift van ochtend naar avond
  const hemi = new T.HemisphereLight(0xfff4e0, 0x3a3025, 1.0); S.add(hemi);
  const sun = new T.SpotLight(0xffe2b0, 160, 22, 0.55, 0.6, 1.2); sun.position.set(-7, 7, 9); sun.target.position.set(0, -1, -2); S.add(sun, sun.target);
  const rimL = new T.DirectionalLight(0xffffff, 0.6); rimL.position.set(4, 3, 6); S.add(rimL);

  // --- maat & zichtbaarheid
  let zOff = 0;
  const size = () => { const w = box.clientWidth || 1, h = box.clientHeight || 1; R.setSize(w, h, false); cam.aspect = w / h;
    cam.fov = Math.min(78, Math.max(40, 2 * Math.atan(Math.tan(31 * Math.PI / 180) / cam.aspect) * 180 / Math.PI)); zOff = cam.aspect < 1 ? 2.5 : 0; cam.updateProjectionMatrix(); };
  size(); addEventListener('resize', size); if ('ResizeObserver' in window) new ResizeObserver(size).observe(box);
  let vis = true; new IntersectionObserver(([e]) => vis = e.isIntersecting, { rootMargin: '100px' }).observe(box);

  // --- scroll-voortgang
  const [p0, p1] = VIEW[view] || [0, 1]; const st = { p: RM ? (p0 + p1) / 2 : p0 };
  if (view !== 'index' && !RM) ST.create({ trigger: box.closest('section') || box, start: 'top bottom', end: 'bottom top', scrub: 1, onUpdate: s => { st.p = p0 + (p1 - p0) * s.progress; } });
  if (view === 'reserveren' && !RM) st.p = p0;

  // --- drag ±0.6
  const drag = { x: 0, y: 0, tx: 0, ty: 0, on: false, sx: 0, sy: 0 };
  cv.addEventListener('pointerdown', e => { drag.on = true; drag.sx = e.clientX - drag.tx * 400; drag.sy = e.clientY - drag.ty * 400; cv.setPointerCapture(e.pointerId); cv.style.cursor = 'grabbing'; });
  cv.addEventListener('pointermove', e => { if (!drag.on) return; drag.tx = Math.max(-0.6, Math.min(0.6, (e.clientX - drag.sx) / 400)); drag.ty = Math.max(-0.25, Math.min(0.25, (e.clientY - drag.sy) / 400)); });
  const up = () => { drag.on = false; cv.style.cursor = 'grab'; }; cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);

  const tmp = new T.Vector3(), look = new T.Vector3(), ez = t => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
  let t0 = performance.now();
  R.setAnimationLoop(() => { if (!vis) return; const now = performance.now(), t = (now - t0) / 1000;
    let p = view === 'index' ? (window.__raamP ?? 0) : st.p; if (RM) p = (p0 + p1) / 2;
    if (!drag.on) { drag.tx *= 0.94; drag.ty *= 0.94; } drag.x += (drag.tx - drag.x) * 0.12; drag.y += (drag.ty - drag.y) * 0.12;
    // camera: 0–0.55 dolly door het glas (z 8 → -3), 0.55–1 omdraaien naar het raam (spiegelschrift)
    const a = ez(clamp(p / 0.55)), b2 = ez(clamp((p - 0.55) / 0.45));
    const z = 8.5 + zOff - (14 + zOff * 0.6) * a, turn = Math.PI * b2;
    tmp.set(Math.sin(t * 0.25) * 0.08 + 1.6 * b2 * (1 - b2), 0.15 + Math.sin(t * 0.3) * 0.04 - 0.2 * b2, z);
    cam.position.copy(tmp);
    const yaw = turn + drag.x, pitch = drag.y * 0.5;
    look.set(tmp.x - Math.sin(yaw), tmp.y + pitch + 0.05, tmp.z - Math.cos(yaw));
    cam.lookAt(look);
    // licht: dag → avond
    const ev = view === 'contact' ? 0.7 + 0.3 * p : clamp((p - 0.35) / 0.6);
    S.background.copy(bgDay).lerp(bgEve, ev); S.fog.color.copy(S.background);
    sun.position.x = -7 + 14 * clamp(p * 1.1); sun.intensity = 160 * (1 - ev * 0.85); sun.color.setHSL(0.09, 0.9, 0.78 - ev * 0.12);
    hemi.intensity = 1.0 - ev * 0.7; lamps.forEach((l, i) => { l.intensity = 9 * ev * (0.92 + 0.08 * Math.sin(t * 3 + i)); }); bulbM.emissiveIntensity = 0.4 + 2.6 * ev; facM.emissiveIntensity = 1.4 * ev; facM.color.setScalar(1 - 0.8 * ev);
    glassM.roughness = 0.04 + 0.02 * Math.sin(t * 0.5);
    R.render(S, cam); });
}

const boxes = [...document.querySelectorAll('.raam3d')];
boxes.forEach(b => scene(b).catch(e => { console.warn('raam', e); b.classList.add('nogl'); }));
