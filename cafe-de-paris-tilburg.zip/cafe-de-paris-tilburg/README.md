# Café de Paris, Tilburg — website

Statische site, klaar voor Cloudflare Workers (assets-only). Idee: «Een tafeltje in Parijs. *Midden in Tilburg.*» — het gouden opschrift op het raam: van buiten lees je Tilburg, van binnen (in spiegelschrift) Parijs. Een scrollfilm neemt je mee van de straat, door het glas, langs de bar tot de avond.

## Structuur
- `public/` — de hele site: `index.html`, `kaart.html`, `over.html`, `reserveren.html`, `contact.html`, `404.html`
- `public/assets/` — css, js (`site.js` effecten, `raam.js` Three.js «Het Raam»), video (scrollfilm 1920 + mobiel 900), img, fonts (OFL, lokaal woff2), vendor (GSAP, Lenis, Three.js, motion-kit)
- `_notes/build.py` — genereert de HTML uit de data → `python3 _notes/build.py`; `_notes/prep.py` — assets (vendor, fonts, beelden); `_notes/zp.sh` + `_notes/up.sh` — video's
- `wrangler.jsonc` — Workers-config (name `cafe-de-paris-tilburg`, assets `./public`)

## Publiceren
```bash
npx wrangler login      # eenmalig
npx wrangler deploy     # vanuit deze map
```
Lokaal bekijken (met Range-ondersteuning voor de scrollvideo): `python3 _review/serve.py public 8080`.

## Bij publicatie op het eigen domein
- Vervang de plaatshouder `DOMEIN.nl` in `public/robots.txt` en `public/sitemap.xml` door het echte domein.
- Zet in `_notes/build.py` (functie `head`) og:image op de volledige URL (`https://<domein>/assets/img/og.jpg`) en voeg een canonical toe (`<link rel="canonical" href="https://<domein>/<pagina>">`); daarna `python3 _notes/build.py`.

## Nog bevestigen met de zaak (staat bewust neutraal op de site)
- Openingstijden — niet gevonden; op de site staat «Bel ons voor openingstijden».
- Kaart en prijzen — niet gevonden; `kaart.html` toont alleen rubrieken als «voorbeeldassortiment», zonder prijzen.
- Geen reviews, e-mail, Instagram of Facebook gevonden — niet gebruikt.
- Terras / indeling van de zaal: de plattegrond op `reserveren.html` is schematisch (raam / zaal / bar). Het formulier verstuurt niets (eerlijke demo-melding) en verwijst naar bellen: +31 13 536 9333.
- Beelden zijn sfeerbeelden (gegenereerd), geen foto's van de zaak. Kaart: OpenStreetMap-embed op de coördinaten 51.5558562, 5.0899447.
- KvK: Non-Mailing-Indicator — geen ongevraagde post.
- `public/robots.txt` en `public/sitemap.xml` bevatten de plaatshouder `DOMEIN.nl`: vervang die door het echte domein (zoek-en-vervang in beide bestanden). `public/_headers` geeft video's, fonts en vendor een lange cache (1 jaar, immutable).
- og:image staat relatief (`assets/img/og.jpg`). Zodra het domein bekend is: in `_notes/build.py` (functie `head`) de volledige URL invullen en opnieuw bouwen.
