# COPY (NL) — Café de Paris, Tilburg
Без выдуманных фактов. Где данных нет — «Bel ons».

## Globaal
Nav: Kaart · Over ons · Reserveren · Contact · CTA «Bel ons» (tel:+31135369333)
Footer: Café de Paris · Emmastraat 1b · 5038 WB Tilburg · +31 13 536 9333 · gigantisch woord «PARIS»
Voorbeeldassortiment-label: «Voorbeeld — bel ons voor het actuele aanbod.»

## index
Hero: «Een tafeltje in Parijs. *Midden in Tilburg.*» · sub «Café de Paris aan de Emmastraat. Schuif aan, wij zetten de koffie.» · knoppen «Reserveer een tafeltje» / «Bel ons»
Scroll «Een dag aan het tafeltje» (TAFEL 01–05 / 05):
01 Ochtend — «Het licht valt door het raam. De dag begint met een kop koffie.»
02 Middag — «Dichterbij. Het gouden opschrift, het marmeren tafeltje, de stoelen in de zon.»
03 Binnen — «Stap door het glas. Van Tilburg naar Parijs in één stap.»
04 Borrel — «Langs de bar: glazen, koper, een plek om te blijven.»
05 Avond — «De lampen gaan aan. Tot morgen.»
Plek: «Midden in het centrum, op een paar stappen van de Paleisring.»
CTA-blok: «Even naar Parijs? Het is om de hoek.» · «Bel ons voor openingstijden en tafels: +31 13 536 9333»

## kaart
H1 «De kaart» · «Een voorbeeld van wat je bij een café als dit verwacht: koffie, thee, bier, wijn en iets kleins erbij.» · Label «Voorbeeldassortiment — geen actuele kaart of prijzen.» · «Prijzen en het actuele aanbod? Bel ons: +31 13 536 9333.» (rubrieken: Koffie & thee · Bier & wijn · Iets erbij — zonder prijzen)

## over-ons
H1 «Over ons» · «Café de Paris zit aan de Emmastraat 1b, in het centrum van Tilburg, vlak bij de Paleisring.» · «Het raam: een gouden opschrift op glas, van buiten gelezen als Tilburg, van binnen als Parijs.» · «Meer over ons verhaal? Kom langs of bel ons.»

## reserveren (demo)
H1 «Reserveer je tafeltje» · velden: Naam · Aantal gasten (1–8) · Gewenste dag · Gewenste tijd · Opmerking · knop «Verstuur aanvraag (demo)» · melding «Dit is een demo: er wordt niets verstuurd. Bel ons om echt te reserveren: +31 13 536 9333.»

## contact
H1 «Contact» · Adres «Emmastraat 1b, 5038 WB Tilburg» · Telefoon «+31 13 536 9333» · Openingstijden «Bel ons voor openingstijden.» · Kaart OSM (51.5558562, 5.0899447) in boog-masker · «Route: wandel vanaf de Paleisring, zo’n 70 meter.»
