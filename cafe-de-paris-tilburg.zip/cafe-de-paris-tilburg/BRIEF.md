# BRIEF — Café de Paris, Tilburg (23.11.2026)
Клиент: Café de Paris, Emmastraat 1b, 5038 WB Tilburg, тел. +31 13 536 9333. Сайта нет. Факты — только _notes/FACTS.md; часов, меню, цен, отзывов нет.
Концепция (BRAND.md №1): «Parijs, Emmastraat 1b» — витрина с бладгоуд-надписью = граница двух городов. Слоган «Een tafeltje in Parijs. *Midden in Tilburg.*»
Цель сайта: показать атмосферу, дать позвонить/«забронировать» (демо-форма → звонок). Язык: NL.
Страницы (5): index · kaart (voorbeeldassortiment-заглушка, без цен) · over-ons · reserveren (демо-форма/конфигуратор) · contact (карта OSM).
Фильм прокрутки: «Een dag aan het tafeltje» K1..K7 (STORY.md), LTX-клипы c1..c6, hero index — kling3_0 K1→K2 по ★ ПЛАНКЕ при наличии, иначе LTX.
Палитра/шрифты/motion — BRAND.md (flessengroen #1E4A38, crème #F3ECDF, bladgoud #C29A45; Instrument Serif / Work Sans / Fragment Mono; эффект «Bladgoud», шторка «Luifel», Three.js «Het Raam»).
Правила: без людей и рук в кадрах; не выдумывать часы/меню/цены/отзывы; форма — демо (честная пометка); Non-Mailing-Indicator в KvK — не слать рассылки.
